import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import Twist
import numpy as np


#Definición de la clase 
class Controller(Node):
    #Constructor 
    def __init__(self):
        
        #Definición del tópico
        super().__init__('Azul_Controller_node')

        #Variables para lectura de topico /odom
        self.x = 0.0
        self.y = 0.0
        self.w = 0.0

        #Punto objetivo

        self.xp = 1.0
        self.yp = 1.0
        self.wp = 0.785398
        #self.wp = np.arctan2(self.yp,self.xp) #pi radianes
        
        #Definición del periodo de tiempo
        timer_period = 0.01

        #Creación del tópico publicador: Azul_Error
        self.publisher = self.create_publisher(Pose2D, 'error_position', 10)
        
        #Creación del tópico subcriptor: pose
        self.subscriber = self.create_subscription(Pose2D, 'odom', self.pose_callback, 10)

        #Timer para operaciones
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #Confirmación de la creación del nodo
        self.get_logger().info('Controller position error node successfully initialized!!!')

        #Tipo de mensaje 
        self.msg = Float32()
    
    def pose_callback(self, msg):
        #Datos de pose recibidos
        self.x = msg.x
        self.y = msg.y
        self.w = msg.theta
        self.get_logger().info(f'Received pose: x={msg.x}, y={msg.y}, theta={msg.theta}')

    #Método del timer
    def timer_callback(self):
        cmd_vel = Twist()
        pose_msg = Pose2D()
        
        self.x = float(self.x)
        self.y = float(self.y)
        self.w = float(self.w)

        #Calculo de errores 
        pose_msg.x = self.xp - self.x
        pose_msg.y = self.yp - self.y
        pose_msg.theta = self.wp - self.w

        #Publicar errores
        self.publisher.publish(pose_msg)

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Controller()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == 'main':    
    main()
    
'''[controller-1] [INFO] [1705500775.636024685] [Azul_Controller_node]: Controller position error node successfully initialized!!!
[controller-1] Traceback (most recent call last):
[controller-1]   File "/home/puzzlebot/ros2_ws/install/error_rigo/lib/error_rigo/controller", line 11, in <module>
[controller-1]     load_entry_point('error-rigo==0.0.0', 'console_scripts', 'controller')()
[controller-1]   File "/home/puzzlebot/ros2_ws/install/error_rigo/lib/python3.8/site-packages/error_rigo/controller.py", line 78, in main
[controller-1]     rclpy.spin(m_p)
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/__init__.py", line 222, in spin
[controller-1]     executor.spin_once()
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/executors.py", line 739, in spin_once
[controller-1]     self._spin_once_impl(timeout_sec)
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/executors.py", line 736, in _spin_once_impl
[controller-1]     raise handler.exception()
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/task.py", line 239, in __call__
[controller-1]     self._handler.send(None)
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/executors.py", line 437, in handler
[controller-1]     await call_coroutine(entity, arg)
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/executors.py", line 362, in _execute_subscription
[controller-1]     await await_or_execute(sub.callback, msg)
[controller-1]   File "/opt/ros/humble/lib/python3.8/site-packages/rclpy/executors.py", line 107, in await_or_execute
[controller-1]     return callback(*args)
[controller-1]   File "/home/puzzlebot/ros2_ws/install/error_rigo/lib/python3.8/site-packages/error_rigo/controller.py", line 49, in pose_callback
[controller-1]     self.x = msg.x.data
[controller-1] AttributeError: 'float' object has no attribute 'data'
[ERROR] [controller-1]: process has died [pid 6769, exit code 1, cmd '/home/puzzlebot/ros2_ws/install/error_rigo/lib/error_rigo/controller --ros-args'].
'''
