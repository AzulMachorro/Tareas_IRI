#import ros_actions for node
from launch_ros.actions import Node
#import launch description
from launch import LaunchDescription

#Generate launch description Fnc
def generate_launch_description():

    #launch node methd
    controller = Node(
        #Definition for node parameters 
        package='error_rigo',
        executable='controller',
        output='screen',
    )

    odometry_node = Node(
        #Definition for node parameters 
        package='error_rigo',
        executable='odometry_node',
        output='screen',
    )
    
    #creates the launcher 
    ld = LaunchDescription([controller,odometry_node])
    #return launcher
    return ld
